(function (window, angular, undefined) {

	var app = angular.module('controllers', ['RegisterCtrl']);

})(window, window.angular, void 0);