(function (window, angular, undefined) {

	var app = angular.module('factories', []);

})(window, window.angular, void 0);