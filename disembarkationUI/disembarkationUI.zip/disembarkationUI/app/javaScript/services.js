(function (window, angular, undefined) {

	var app = angular.module('services',[]);

})(window, window.angular, void 0);